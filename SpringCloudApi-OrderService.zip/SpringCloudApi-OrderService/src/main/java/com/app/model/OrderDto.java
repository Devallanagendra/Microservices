package com.app.model;

import javax.validation.constraints.NotEmpty;

public class OrderDto {

	@NotEmpty(message = "Customer Name mandatory")
	private String customerName;
	@NotEmpty(message = "Customer Address mandatory")
	
	private String orderStatus;
	private int pId;
	private int quantity;
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
