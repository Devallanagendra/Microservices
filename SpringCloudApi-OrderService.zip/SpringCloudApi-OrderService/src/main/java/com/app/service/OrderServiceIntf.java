package com.app.service;

import java.util.List;
import java.util.Optional;

import com.app.model.Order;

public interface OrderServiceIntf {

	void saveOrder(Order order);

	List<Order> fetchOrder();

	Optional<Order> getOrderById(int orderId);
}
