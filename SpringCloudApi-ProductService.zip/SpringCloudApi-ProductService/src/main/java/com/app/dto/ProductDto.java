package com.app.dto;

import javax.validation.constraints.NotEmpty;

public class ProductDto {
	
	private int pId;
	@NotEmpty(message = "Product Name is Mandatory")
	private String pName;
	@NotEmpty(message = "Product Category is Mandatory")
	private String pCategory;
	@NotEmpty(message = "Price is Mandatory")
	private double pPrice;
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public String getpCategory() {
		return pCategory;
	}
	public void setpCategory(String pCategory) {
		this.pCategory = pCategory;
	}
	
	public double getpPrice() {
		return pPrice;
	}
	public void setpPrice(double pPrice) {
		this.pPrice = pPrice;
	}
	@Override
	public String toString() {
		return "ProductDto [pId=" + pId + ", pName=" + pName + ", pCategory=" + pCategory +  ", pPrice=" + pPrice + "]";
	}
	
	

}
