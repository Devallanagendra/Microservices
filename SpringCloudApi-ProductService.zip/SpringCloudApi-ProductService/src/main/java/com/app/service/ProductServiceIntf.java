package com.app.service;

import java.util.List;
import java.util.Optional;

import com.app.model.Product;

public interface ProductServiceIntf {

	void saveProduct(Product product);

	List<Product> getAllProducts();

	Optional<Product> getProductById(int pId);

	Object updateProduct(Product product);
	
	

}
